#include <iostream>
using namespace std;


int persegi(){
    int s;
    cout << "Masukkan ukuran panjang sisi persegi: ";
    cin >> s;
    cout << "Luas persegi dengan panjang sisi: " << s << " adalah " << s*s << endl;

    return 0;
}
